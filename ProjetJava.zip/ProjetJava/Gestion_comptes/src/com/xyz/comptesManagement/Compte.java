package com.xyz.comptesManagement;

import java.util.List;

public class Compte {
    private int id;
    private String numero;
    private List<Operation> operations;
    private double soldeCourant;
    private Client client;

    public Compte(int id, String numero, List<Operation> operations, double soldeCourant, Client client) {
        this.id = id;
        this.numero = numero;
        this.operations = operations;
        this.soldeCourant = soldeCourant;
        this.client = client;
    }

    public int getId() {
        return id;
    }

    public String getNumero() {
        return numero;
    }

    public List<Operation> getOperations() {
        return operations;
    }

    public double getSoldeCourant() {
        return soldeCourant;
    }

    public Client getClient() {
        return client;
    }
}
